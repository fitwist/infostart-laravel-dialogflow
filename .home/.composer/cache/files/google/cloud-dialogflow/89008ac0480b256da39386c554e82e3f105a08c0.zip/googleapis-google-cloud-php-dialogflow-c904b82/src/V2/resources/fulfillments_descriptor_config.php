<?php

return [
    'interfaces' => [
        'google.cloud.dialogflow.v2.Fulfillments' => [],
    ],
];
